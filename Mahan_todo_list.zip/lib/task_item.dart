import 'package:flutter/material.dart';
import 'package:main_todo_list/Models/Tasks.dart';
import 'package:main_todo_list/Screen/task_detail.dart';
class TaskItem extends StatefulWidget {
  final Task task;
  TaskItem(this.task,this.changeIsDone,this.deleteTask,this.index,this.returnedList,this.updater);
  final Function changeIsDone;
  final Function deleteTask;
  final Function updater;
  final int index;
  final List<Task> returnedList;

  @override
  State<TaskItem> createState() => _TaskItemState();
}

class _TaskItemState extends State<TaskItem> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: 5,
        vertical: 12,
      ),
      margin: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Color(0xFFFFFBA2),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF6F5B3E),
            blurRadius: 5,
            offset: Offset(3, 6),
          ),
        ],
      ),
      child: Container(
        padding: EdgeInsets.only(left: 20),
        child: ListTile(
          leading: GestureDetector(
            onTap: () {
              widget.changeIsDone();
            },
            child: Container(
              // height: 40,
              // width: 60,
              child: Image(
                        image: AssetImage(
                          widget.task.isDone
                              ? 'assets/images/checked.png' : 'assets/images/unchecked.png',
                        )
                    ),
            ),
          ),
          title: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TaskDetail(
                    index: widget.index,
                    returningList: widget.returnedList,
                    changeIsDone: () {
                      widget.changeIsDone();
                    },
                    updater: widget.updater,
                  ),
                ),
              );
            },
            child: Text(
                widget.task.title,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          subtitle: Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
                widget.task.description,
              style: TextStyle(
                color: Color(0xFF5a5d63),
                fontSize: 15,
                fontWeight: FontWeight.bold,
                height: 1.2,
              ),
            ),
          ),
          hoverColor: Colors.black,
          trailing: Container(
              height: 40,
              width: 120,
              child: GestureDetector(
              onTap: () {
                widget.deleteTask();
              },
                child: Row(
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(right: 5),
                        child: Image(
                          image: DateTime.now().isAfter(widget.task.date)
                              ? AssetImage('assets/images/expired2.png')
                              : AssetImage('assets/images/null.png'),),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 0),
                      child: Image(

                        image: AssetImage('assets/images/delete1.png'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ),
      ),
    );
  }
}
