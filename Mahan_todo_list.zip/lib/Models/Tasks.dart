class Task{
  String title;
  String description;
  DateTime date ;
  bool isDone;
  final int defaultYear = 2022;
  Task({this.title, this.description, this.isDone, this.date});
  void setTitle(String title){
    this.title = title;
  }
  void setDescription(String description){
    this.description = description;
  }
  void setDate(DateTime date){
    this.date = date;
  }
  void setIsDone(bool isDone){
    this.isDone = isDone;
  }
  String getTitle(){
    return title;
  }
  String getDescription(){
    return description;
  }
  DateTime getDate(){
    return date;
  }
  bool getIsDone(){
    return isDone;
  }
  @override
  String toString() {
    return 'Task{Title: $title, description: $description, date: $date, isDone: $isDone}';
  }
}