// import 'package:flutter/material.dart';
// import 'package:main_todo_list/main.dart';
//
// import 'home.dart';
//
// class Splash extends StatefulWidget {
//   const Splash({Key key}) : super(key: key);
//
//   @override
//   State<Splash> createState() => _SplashState();
// }
//
// class _SplashState extends State<Splash> {
//   @override
//   void initState() {
//     super.initState();
//     _navigateToHome();
//   }
//
//   _navigateToHome() async {
//     await Future.delayed(Duration(seconds: 3), () {});
//     Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(
//             builder: (context) => MyApp( )
//         )
//     );
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         color: Colors.white,
//         child: Center(
//           child: Text('Splash'),
//         ),
//       ),
//     );
//   }
// }
