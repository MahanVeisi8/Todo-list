import 'package:flutter/material.dart';
import 'package:main_todo_list/Models/Tasks.dart';
class AddTaskPage extends StatefulWidget {
  const AddTaskPage({Key key, this.addTask}) : super(key: key);
  final Function addTask;
  @override
  State<AddTaskPage> createState() => _AddTaskPageState();
}

class _AddTaskPageState extends State<AddTaskPage> {
  TextEditingController titleC;
  TextEditingController descriptionC;
  DateTime date;
  TimeOfDay selectedTime = TimeOfDay.now();
  void initState() {
    titleC = TextEditingController();
    descriptionC = TextEditingController();

    super.initState();
  }

  void dispose() {
    titleC.dispose();
    descriptionC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFFBA2),
      body: SafeArea(
        child: Container(
          child: Stack(
            children: [
              Column(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 20,
                        ),
                        child: Row(
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: SafeArea(
                                child: Container(
                                  child: Icon(
                                    Icons.arrow_back_ios_rounded,
                                    color: Colors.amber,
                                    size: 35,
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  child: Flexible(
                                    child: TextField(
                                      decoration: InputDecoration(
                                        hintText: 'Task\'s title : ...',
                                        hintStyle: TextStyle(
                                            color: Colors.grey,
                                            fontSize: 30,
                                            fontWeight: FontWeight.w300),
                                        border: InputBorder.none,
                                      ),
                                      style: TextStyle(
                                        color: Color(0xFF1e1f15),
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'mozart',
                                      ),
                                      maxLines: null,
                                      controller: titleC,
                                      keyboardType: TextInputType.multiline,
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Container(
                          child: Flexible(
                            child: TextField(
                              onSubmitted: (value) {
                                print(value);
                              },
                              decoration: InputDecoration(
                                hintText: 'Task\'s description: ...',
                                hintStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w300),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: 30,
                                  vertical: 5,
                                ),
                              ),
                              style: TextStyle(
                                color: Color(0xFF1e1f15),
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                overflow: TextOverflow.ellipsis,
                              ),
                              controller: descriptionC,
                              keyboardType: TextInputType.multiline,
                              maxLines: null,
                            ),
                          ),
                        ),
                      ),
                      Center(
                        child: Container(
                          margin: EdgeInsets.only(top: 10),
                          width: 80,
                          height: 40,
                          child: ElevatedButton(
                            onPressed: () {
                              String title = titleC.text;
                              String description = descriptionC.text;
                              DateTime finalDate = date;
                              Task task = Task(
                                  title: title,
                                  description: description,
                                  isDone: false,
                                  date:  finalDate
                              );
                              widget.addTask(task);
                              titleC.clear();
                              descriptionC.clear();
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Add',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Positioned(
                bottom: 70,
                right: 40,
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: Image(
                          image: AssetImage('assets/images/date.png'),
                        ),
                      ),
                      RaisedButton(
                          color: Color(0xFFffcd00),
                          child: Text('select date'),
                          onPressed: () {
                            showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(2022),
                              lastDate: DateTime(2024),
                            ).then((date) {
                              setState(() {
                                this.date = date;
                              });
                            });
                          })
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 70,
                left: 40,
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Image(
                        image: AssetImage('assets/images/clock.png'),
                      ),
                      RaisedButton(
                          color: Color(0xFFffcd00),
                          child: Text('select time'),
                          onPressed: () {
                            showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            ).then((time) {
                              setState(() {
                                this.date = DateTime(
                                    this.date.year,
                                    this.date.month,
                                    this.date.day,
                                    time.hour,
                                    time.minute); //todo
                              });
                            });
                          })
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 20,
                width: MediaQuery.of(context).size.width,
                child: Container(
                  color: Color(0xFFffcd00),
                  height: 50,
                  width: double.infinity,
                  child: Text(
                    date == null ? 'No time chosen!' : date.toString(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 30,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
