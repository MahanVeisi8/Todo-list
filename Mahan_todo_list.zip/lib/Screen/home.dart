// import 'package:main_todo_list/Screen/splash.dart';
// import 'package:main_todo_list/main.dart';
// import 'package:flutter/material.dart';
// class MyApp extends StatelessWidget {
//   const MyApp({Key key}) : super(key: key);
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: Splash(),
//       // home: ToDoList(),
//     );
//   }
// }
