import 'package:flutter/material.dart';
import 'package:main_todo_list/Models/Tasks.dart';
class TaskDetail extends StatefulWidget {
  const TaskDetail({Key key,this.index,this.returningList,this.mainChangeIsDone, changeIsDone, this.updater}) : super(key: key);
  final int index;
  final List<Task> returningList;
  final Function mainChangeIsDone;
  final Function updater;
  @override
  State<TaskDetail> createState() => _TaskDetailState();
}
class _TaskDetailState extends State<TaskDetail> {
  void changeIsDone(int index){
    setState(() {
      widget.returningList[index].isDone = !widget.returningList[index].isDone;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFFBA2),
      body: SafeArea(
        child: Container(

          child: Stack(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 20,
                    ),
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: SafeArea(
                            child: Container(
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Colors.amber,
                                size: 35,
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              child: Flexible(
                                  child: Text(
                                    widget.returningList[widget.index].title,
                                    style: TextStyle(
                                      color: Color(0xFF1e1f15),
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'mozart',
                                    ),
                                    maxLines: null,
                                    textAlign: TextAlign.center
                                  ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 20,
                      ),
                      child: Flexible(
                        child: Text(
                          widget.returningList[widget.index].description,
                          style: TextStyle(
                            color: Color(0xFF1e1f15),
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'mozart',
                            overflow: TextOverflow.ellipsis,
                          ),
                          maxLines: null,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                top: (MediaQuery.of(context).size.height) * 0.7,
                // left: 40,
                left: (MediaQuery.of(context).size.width) * 0.35,
                child: Container(
                  child: GestureDetector(
                       onTap: () {
                         setState(() {
                          changeIsDone(widget.index);
                          widget.updater;
                         });
                       },

                    child: Image(
                        image: AssetImage(
                          widget.returningList[widget.index].isDone
                              ? 'assets/images/checked100pixel.png' : 'assets/images/unchecked100pixel.png',
                        )

                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 20,
                width: MediaQuery.of(context).size.width,
                child: Container(
                  color: Color(0xFFffcd00),
                  height: 50,
                  width: double.infinity,
                  child: Text(
                    widget.returningList[widget.index].date.toString() == null
                        ? 'No date chosen :('
                        : widget.returningList[widget.index].date.toString(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 30,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
