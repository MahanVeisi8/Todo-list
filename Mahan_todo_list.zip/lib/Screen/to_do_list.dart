import 'package:flutter/material.dart';
import 'package:main_todo_list/Models/Tasks.dart';
import 'package:main_todo_list/task_item.dart';
import 'package:main_todo_list/Screen/add_task_page.dart';
class ToDoList extends StatefulWidget {
  @override
  State<ToDoList> createState() => _ToDoListState();
}

class _ToDoListState extends State<ToDoList> {
  static List<Task> tasks = [];
  static int sizeOfTask = 0;
  void updater() {
    setState(() {
    });
  }
  void changeIsDone(int index){
    setState(() {
       tasks[index].isDone = !tasks[index].isDone;
    });
  }
  void sortByDate(){
    setState(() {
      tasks.sort((a,b) => a.date.compareTo(b.date));
    });
  }
  void addTask(Task task){
    setState(() {
      tasks.add(task);
      ++sizeOfTask;
      sortByDate();
    });
  }
  void deleteTask(int index){
    setState(() {
      tasks.removeAt(index);
      --sizeOfTask;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: 20,
          ),
          color: Color(0xFFf3ca20),
          child: Column(
            children: [
              Image(
                image: AssetImage('assets/images/mahan_company.png'),
              ),
              Container(
                margin: EdgeInsets.only(
                  bottom: 2,
                ),
                child: Text(
                  'Mahan Company',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                    itemCount: sizeOfTask,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (context, index) {
                      return TaskItem(
                        tasks[index],
                        () => changeIsDone(index),
                        () => deleteTask(index),
                        index,
                        tasks,
                        () => updater(),
                      );
                      // return TaskItem(
                      //   tasks[index], () => changeIsDone(index),
                      // );
                    }),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFFFFFBA2),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) {
                      return AddTaskPage(
                        addTask: addTask,
                      );
                    },
            ),
          );
        // () => sortByDate();
        },
        child: Icon(Icons.add, color: Colors.black),
      ),
    );
  }
}
